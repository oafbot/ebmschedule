import MySQLdb
from decimal import *
from datetime import timedelta, datetime

from Config import Config
from InitialConditions import InitialConditions
from objects import Asset, Skill, Manpower, Usage
from objects.Task import Task
from objects.Schedule import Schedule
from objects.DateRange import DateRange

class BigModel:
    
    def __init__(self, count, metrics, conf=Config()):        
        self.conf    = conf        
        self.name    = "Big-Model"
        self.trace   = self.conf.trace
        self.bigdata = self.conf.bigdata
        self.year    = self.conf.year
        self.month   = self.conf.month
        self.day     = self.conf.day
        self.start   = self.conf.start
        self.end     = self.conf.end
        self.count   = count
        self.hours   = Decimal(repr(3.83))
        self.metrics = metrics
                        
        """Initialize database connection."""
        conn = MySQLdb.connect (host = self.conf.dbhost, user = self.conf.dbuser, 
                                passwd = self.conf.dbpass, db = self.conf.dbname)
        cursor = conn.cursor ()
        
        workhours = self.conf.hours
        platform = 1
        schedule = Schedule(self.name, DateRange(self.start, self.end), self.conf.max, workhours)
        
        """Initialize arrays for tasks, assets, and skills."""
        tasks  = {}
        assets = {}
        skills = {}
        usage  = {}
        
        """Fetch Assets."""
        # cursor.execute ("SELECT platformId, id, name, serviceStartDate FROM endItem WHERE platformId = %s", (platform))
        cursor.execute ("SELECT platformId, id, name, serviceStartDate FROM enditem WHERE parentId IS NULL AND platformId = %s", (platform))
        row = cursor.fetchall()
        for r in row:
            split = str(r[3]).split("-")
            date = datetime(int(split[0]),int(split[1]),int(split[2]))
            assets[r[1]] = Asset(r[1], r[2], date)
            
        """Fetch Skills."""
        cursor.execute ("SELECT id, name, available FROM skill WHERE platformId = %s", (platform))
        row = cursor.fetchall()
        for r in row:
            skills[r[0]] = Skill(r[0], r[1], r[2], workhours)
        
        """Fetch Usage."""            
        for asset in assets:
             cursor.execute ("SELECT usageTotal, unitId, DATE(recordedOn) FROM ActualUsage WHERE recordedOn >'2010-12-31' AND recordedOn < '2012-01-01' AND endItemId = %s", (asset))
             # cursor.execute ("SELECT usageAmount, unitId, monthYear FROM  plannedusage WHERE  monthYear >'2012-12-31' AND monthYear < '2014-01-01' AND endItemId = %s", (asset))
             row = cursor.fetchall()
             for r in row:
                 date = r[2] + timedelta(days=730.48)
                 schedule.usage.add(date, asset, r[0])
        
        """Fetch Task and associated subcomponents."""
        cursor.execute("SELECT id, name, description FROM task WHERE active = 1 AND platformId = %s", (platform))
        row = cursor.fetchall()

        for r in row:    
            id   = r[0]
            name = r[1]    
            desc = r[2]

            manpowers = []
            conflicts = []
            subseq    = []
            prep      = []
            prereq    = []
            concur    = []

            """Fetch unconverted values for threshold and interval."""
            cursor.execute("SELECT threshold, taskunit.interval, unitId FROM taskunit WHERE taskId = %s", (id))
            taskunit = cursor.fetchone()
            threshold = taskunit[0] 
            interval = taskunit[1]
            unitid = taskunit[2]

            """Fetch the units of measure associated with the task."""
            cursor.execute("SELECT name FROM unit WHERE id = %s", (unitid))
            baseunit = cursor.fetchone()[0]

            """Convert the threshold and intervals into Days from original unit of measure."""
            if(baseunit == "Operating Hours"):
                threshold = round(threshold / self.hours)
                interval  = round(interval  / self.hours)
            elif(baseunit == "Flight Hours"):
                threshold = round(threshold / self.hours)
                interval  = round(interval  / self.hours)
                # if(interval > 0):
                #     print id, desc, interval
            elif(baseunit == "Days"):
                pass
            elif(baseunit == "Months"):
                threshold *= 30
                interval  *= 30
            elif(baseunit == "Years"):
                threshold *= 365
                interval  *= 365
            elif(baseunit == "Miles"):
                threshold = round((threshold * Decimal("0.033333333")) / hours)
                interval  = round((interval  * Decimal("0.033333333")) / hours)
            else: 
                raise Exception("Unit type " + baseunit + " not recoginized.")

            """Convert threshold and interval into integers."""
            if(threshold <= 1 and threshold > 0):
                threshold = 1
            else:
                threshold = int(threshold)
            if(interval <= 1 and interval > 0):
                interval = 1
            else:
                interval  = int(interval)
                        

            """Fetch and construct the mapower associated with the task."""    
            cursor.execute("SELECT id, skillId, TaskTime FROM manpower WHERE taskId = %s", (id))
            rows = cursor.fetchall()
            for mp in rows:
                # There is a null field for Task N0. 307264 Hydraulic Vibration Program - monitor vibrations.
                if mp[2] == 'NULL':
                    # print id
                    taskTime = 0.00
                else:
                    taskTime = float(mp[2])
                manpowers.append(Manpower(mp[0], skills[mp[1]], taskTime))
                
            """Fetch confilcts."""
            cursor.execute("SELECT configurationId FROM taskConfiguration WHERE taskId = %s", (id))
            rows = cursor.fetchall()
            for r in rows:
                configId = r[0]
                cursor.execute("SELECT configurationIdConflict FROM configurationConflict WHERE configurationId = %s", (configId))
                rows = cursor.fetchall()
                for r in rows:
                    confilctId = r[0]
                    cursor.execute("SELECT taskId FROM taskConfiguration WHERE configurationId = %s", (confilctId))
                    rows = cursor.fetchall()
                    for r in rows:
                        conflicts.append(r[0])

            """Fetch prep tasks."""
            cursor.execute("SELECT prereqtasklink.preReqTaskId FROM prereqtasklink, taskunit \
                            WHERE prereqtasklink.taskId = %s \
                            AND prereqtasklink.preReqTaskId = taskunit.taskId \
                            AND taskunit.interval = 0.00", (id))
            rows = cursor.fetchall()
            for r in rows:
                prep.append(r[0])

            """Fetch prerequisite tasks."""
            # cursor.execute("SELECT preReqTaskId FROM prereqtasklink WHERE taskId = %s", (id))
            cursor.execute("SELECT prereqtasklink.preReqTaskId FROM prereqtasklink, taskunit \
                            WHERE prereqtasklink.taskId = %s \
                            AND prereqtasklink.preReqTaskId = taskunit.taskId \
                            AND taskunit.interval > 0.00", (id))
            rows = cursor.fetchall()
            for r in rows:
                prereq.append(r[0])

            """Fetch subsequent tasks."""
            cursor.execute("SELECT postReqTaskId FROM postreqtasklink WHERE taskId = %s", (id))
            rows = cursor.fetchall()
            for r in rows:
                subseq.append(r[0])

            """Fetch concurrent tasks."""
            cursor.execute("SELECT assocTaskId FROM assocTaskLink WHERE taskId = %s", (id))
            rows = cursor.fetchall()
            for r in rows:
                concur.append(r[0])

            tasks[id] = Task(
                id, 
                desc, 
                workhours, 
                threshold, 
                interval, 
                manpowers, 
                conflicts,
                prep,
                prereq,
                subseq,
                concur
            )

        cursor.close ()
        conn.close ()
        
        self.assets = assets.values()
        self.tasks = tasks.values()
        self.skills = skills.values()
        conditions = InitialConditions(self.name, self.count, self.conf)
        self.schedule = conditions.set(assets, tasks, schedule)
        self.metrics.NumberOfAssets = len(assets)