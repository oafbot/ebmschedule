class Inputs:
    def __init__(self, count, metrics, algo):
        from Config import Config
        self.config = Config()
        
        if algo >= 0:
            self.config.algo = int(algo)
        
        if(self.config.bigdata):
            from BigModel import BigModel
            self.model = [BigModel(count, metrics, self.config)]
            # from StaticModel import StaticModel
            # self.model = [StaticModel(count, metrics, self.config)]
        else:
            from Model import Model
            self.model = [Model(count, metrics, self.config)]